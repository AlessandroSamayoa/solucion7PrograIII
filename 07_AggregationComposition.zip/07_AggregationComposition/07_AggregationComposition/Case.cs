﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_AggregationComposition
{
    class Case
    {
        private int id;
        private string problem;
        private string description;

        public Case(int id, string problem, string description)
        {
            this.id = id;
            this.problem = problem;
            this.description = description;
        }

        public int Id { get => id; set => id = value; }
        public string Problem { get => problem; set => problem = value; }
        public string Description { get => description; set => description = value; }
    }
}
