﻿using System;

namespace _07_AggregationComposition
{
    class Employee : Person
    {
        private int employeeNumber;
        private DateTime inDate;
        private Depto depto;

        public Employee(string name, string lastName, DateTime date, string email, int employeeNumber, DateTime inDate, Depto depto) 
            : base(name, lastName, date, email)
        {
            employeeNumber = EmployeeNumber;
            inDate = InDate;
            depto = Depto;
        }

        public int EmployeeNumber { get => employeeNumber; set => employeeNumber = value; }
        public DateTime InDate { get => inDate; set => inDate = value; }
    
        internal Depto Depto
        {
            get => default(Depto);
            set
            {
            }
        }
    }    
}
