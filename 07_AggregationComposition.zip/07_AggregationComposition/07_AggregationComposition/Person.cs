﻿using System;
namespace _07_AggregationComposition
 
{
    abstract class Person
    {
        protected string name;
        protected string lastName;
        private DateTime date;
        protected string email;

        public Person(string name, string lastName, DateTime addDate, string email)
        {
            name = Name;
            lastName = LastName;
            addDate = Date;
            email = Email;
        }

        public string Name { get => name; set => name = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Email { get => email; set => email = value; }
        protected DateTime Date { get => date; set => date = value; }
    }
}
