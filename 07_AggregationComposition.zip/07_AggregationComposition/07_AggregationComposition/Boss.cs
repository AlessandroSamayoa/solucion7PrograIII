﻿using System;
namespace _07_AggregationComposition
{
    internal class Boss : Person
    {

        public Boss(string name, string lastName, DateTime date , string email) 
            : base(name, lastName, date, email)
        {
           
        }
    }
}