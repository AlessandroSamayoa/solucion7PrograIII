﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07_AggregationComposition
{
    class Client : Person
    {
        
        private string customerID;

        public Client(string name, string lastName, DateTime date, string email, string customerID) 
            : base(name, lastName, date, email)
        {
            customerID = CustomerID;
        }

        public string CustomerID { get => customerID; set => customerID = value; }
    }
}
