﻿using System;

namespace _07_AggregationComposition
{
    class Tickets
    {
        private string ticketId;
        private Client client;
        private Case handleCase;
        private Employee employee;
        private bool ticketState;
        private string descriptionCase;

        public Tickets(Client cliente, Case handleCase, Depto department, Employee employee, Boss boss)
        {
            TicketId = Guid.NewGuid().ToString();
            client = Client;
            this.handleCase = handleCase;
            this.employee = employee;
        }

        public string TicketId { get => ticketId; set => ticketId = value; }
        public bool TicketState { get => ticketState; set => ticketState = value; }
        public string DescriptionCase { get => descriptionCase; set => descriptionCase = value; }

        internal Client Client
        {
            get => default(Client);
            set { }
        }

        internal Employee Employee
        {
            get => default(Employee);
            set { }
        }

        internal Case Case
        {
            get => default(Case);
            set { }
        }
    }
}
