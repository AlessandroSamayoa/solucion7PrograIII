﻿namespace _07_AggregationComposition
{
    class Depto
    {
        private int deptoId;
        private string deptoName;
        private Boss deptoBoss;

        public Depto(int deptoId, string deptoName, Boss deptoBoss)
        {
            deptoId = DeptoId;
            deptoName = DeptoName;
            deptoBoss = Boss;
            
        }

        public int DeptoId { get => deptoId; set => deptoId = value; }
        public string DeptoName { get => deptoName; set => deptoName = value; }

        internal Boss Boss
        {
            get => default(Boss);
            set { }
        }
    }
}
